#define GLM_FORCE_DEPTH_ZERO_TO_ONE
#define STB_IMAGE_IMPLEMENTATION

#define GLFW_INCLUDE_VULKAN
#include <GLFW/glfw3.h>
#include <stdexcept>
#include <vector>

#include <string>
using std::string;

#include "VulkanRenderer.h"


GLFWwindow* window = nullptr;
VulkanRenderer vulkanRenderer;

void initWindow(string wName = "Vulkan", const int width = 800, const int height = 600)
{
	// Initialize GLFW
	glfwInit();
	glfwWindowHint(GLFW_CLIENT_API, GLFW_NO_API); 	// Glfw won't work with opengl
	glfwWindowHint(GLFW_RESIZABLE, GLFW_FALSE);

	window = glfwCreateWindow(width, height, wName.c_str(), nullptr, nullptr);
}

void clean()
{
	vulkanRenderer.clean();
	glfwDestroyWindow(window);
	glfwTerminate();
}

int main()
{
	initWindow();
	if(vulkanRenderer.init(window) == EXIT_FAILURE) return EXIT_FAILURE;

	float angle = 0.0f;
	float deltaTime = 0.0f;
	float lastTime = 0.0f;

	// Load model
	int modelId = vulkanRenderer.createMeshModel("models/Futuristic combat jet.obj");

	while (!glfwWindowShouldClose(window))
	{
		glfwPollEvents();

		float now = glfwGetTime();
		deltaTime = now - lastTime;
		lastTime = now;

		angle += 10.0 * deltaTime;
		if (angle > 360.0f) { angle -= 360.0f; }

		glm::mat4 rotationModelMatrix(1.0f);
		rotationModelMatrix = glm::translate(rotationModelMatrix, glm::vec3(-0.0f, 0.0f, -1.0f));
		rotationModelMatrix = glm::rotate(rotationModelMatrix, glm::radians(angle), glm::vec3(0.0f, 1.0f, 0.0f));
		vulkanRenderer.updateModel(modelId, rotationModelMatrix);

		/*
		glm::mat4 firstModel(1.0f);
		firstModel = glm::translate(firstModel, glm::vec3(-0.0f, 0.0f, -1.0f));
		firstModel = glm::rotate(firstModel, glm::radians(angle), glm::vec3(0.0f, 0.0f, 1.0f));
		vulkanRenderer.updateModel(0, firstModel); 
		
		glm::mat4 secondModel(1.0f);
		secondModel = glm::translate(secondModel, glm::vec3(0.0f, 0.0f, -2.0f));
		secondModel = glm::rotate(secondModel, glm::radians(-angle * 100), glm::vec3(0.0f, 0.0f, 1.0f));

		vulkanRenderer.updateModel(1, secondModel);
		*/
		vulkanRenderer.draw();
	}

	clean();
	return 0;
}